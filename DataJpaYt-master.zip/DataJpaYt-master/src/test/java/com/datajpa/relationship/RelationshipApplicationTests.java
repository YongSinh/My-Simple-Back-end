package com.datajpa.relationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
