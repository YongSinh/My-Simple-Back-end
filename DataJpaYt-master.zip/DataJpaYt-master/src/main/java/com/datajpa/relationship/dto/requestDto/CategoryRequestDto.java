package com.datajpa.relationship.dto.requestDto;

import lombok.Data;

@Data
public class CategoryRequestDto {
    private String name;
}
