package com.datajpa.relationship.dto.requestDto;

import lombok.Data;

@Data
public class CityRequestDto {
    private String name;
}
